# Need manually updated
utils::globalVariables(c(
    "_RaspberryPiR_DHT11_freeMemory",

    "_RaspberryPiR_DHT11_readMemory",

    "_RaspberryPiR_DHT11_writeMemory",

    "_RaspberryPiR_LL_digitalRead",

    "_RaspberryPiR_LL_digitalWrite",

    "_RaspberryPiR_LL_micros",

    "_RaspberryPiR_LL_millis",

    "_RaspberryPiR_LL_pinMode",

    "_RaspberryPiR_LL_pullUpDnControl",

    "_RaspberryPiR_LL_wiringPiSetup",

    "_RaspberryPiR_PhotoRes_freeMemory",

    "_RaspberryPiR_PhotoRes_readMemory",

    "_RaspberryPiR_PhotoRes_writeMemory",

    "_RaspberryPiR_simpleCapture",

    "_RaspberryPiR_testing_freeMemory",

    "_RaspberryPiR_testing_readMemory",

    "_RaspberryPiR_testing_writeMemory",

    "_RaspberryPiR_testingDHT",

    "_RaspberryPiR_testingMQ2",

    "_RaspberryPiR_testingPhotoRes"
))