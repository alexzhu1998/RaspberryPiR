#include <stdio.h>

class Fibonacci{
  public:
    int getFibonacciNumber(int n);
};
